using Api.Services.Books;
using Asp.Versioning;
using Microsoft.AspNetCore.Mvc;

namespace Api.v1.Books;

[ApiController, ApiVersion("1.0")]
[Route("api/v{version:apiVersion}/[controller]")]
public class BookOwnersController : ControllerBase
{
    private readonly IBookService _bookService;

    public BookOwnersController(IBookService bookService)
    {
        _bookService = bookService;
    }

    [HttpGet(), MapToApiVersion("1.0")]
    public async Task<IEnumerable<BookOwner>> BookOwners()
    {
        return _bookService.GetBookOwners();
    }
}