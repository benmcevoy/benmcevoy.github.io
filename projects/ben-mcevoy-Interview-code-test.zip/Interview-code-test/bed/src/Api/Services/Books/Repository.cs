namespace Api.Services.Books;

public interface IBookRepository
{
    ICollection<BookOwner> GetBookOwners();
    ICollection<Book> GetBooks();
}

public class InMemoryBookRepository : IBookRepository
{
    public ICollection<Book> GetBooks()
    {
        return All().SelectMany(x => x.Books).ToList();
    }

    ICollection<BookOwner> IBookRepository.GetBookOwners()
    {
        return All();
    }

    private ICollection<BookOwner> All()
    {
        return [
            new BookOwner(
                "Jane",
                23,
                [
                    new Book("Hamlet", BookType.Hardcover),
                    new Book("Wuthering Heights", BookType.Paperback)
                ]),

            new BookOwner(
                "Charlotte",
                14,
                [
                    new Book("Hamlet", BookType.Paperback),
                ]),

            new BookOwner(
                "Max",
                25,
                [
                    new Book("React: The Ultimate Guide", BookType.Hardcover),
                    new Book("Gulliver's Travels", BookType.Hardcover),
                    new Book("Jane Eyre", BookType.Paperback),
                    new Book("Great Expectations", BookType.Hardcover),
                ]),

            new BookOwner(
                "William",
                15,
                [
                    new Book("Great Expectations", BookType.Hardcover),
                ]),

            new BookOwner(
                "Charles",
                17,
                [
                    new Book("Little Red Riding Hood", BookType.Hardcover),
                    new Book("The Hobbit", BookType.Ebook)
                ])
        ];
    }

}
