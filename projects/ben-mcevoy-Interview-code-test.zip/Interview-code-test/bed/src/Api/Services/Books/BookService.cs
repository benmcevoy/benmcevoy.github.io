namespace Api.Services.Books;

public interface IBookService
{
    List<Book> GetBooks();
    List<BookOwner> GetBookOwners();
    List<BookOwner> GetBookOwners(bool isAdult);
}

public class BookService(IBookRepository repository) : IBookService
{
    private readonly IBookRepository _repository = repository;

    public List<BookOwner> GetBookOwners()
    {
        // do not order books alphabetically - as per https://digitalcodingtest.bupa.com.au/swagger/index.html
        return _repository.GetBookOwners().ToList();
    }

    public List<BookOwner> GetBookOwners(bool isAdult)
    {
        // IsAdult is not actually on the Bupa api. But here it is.
        return GetBookOwners()
            .Where(x => x.IsAdult == isAdult)
            .ToList();
    }

    public List<Book> GetBooks()
    {
        return _repository.GetBooks().ToList();
    }
}
