using System.Text.Json.Serialization;

namespace Api.Services.Books;

public class BookOwner(string name, int age, IList<Book> books)
{
    public string Name { get; set; } = name;

    [JsonNumberHandling(JsonNumberHandling.Strict)]
    public int Age { get; set; } = age;
    public IList<Book> Books { get; set; } = books;
    
    [JsonIgnore]
    public bool IsAdult => Age >= 18;
}

public class Book(string name, string type)
{
    public string Name { get; } = name;
    public string Type { get; } = type;
}

public struct BookType
{
    public const string Paperback = "Paperback";
    public const string Hardcover = "Hardcover";
    public const string Ebook = "Ebook";
}