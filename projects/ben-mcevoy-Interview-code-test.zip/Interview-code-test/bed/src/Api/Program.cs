using Api.Services.Books;
using Asp.Versioning;
using Scalar.AspNetCore;

namespace Api;

class Program
{
    static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        // this OpenApi support is new(ish) bit of a pain setting this up
        // this was helpful
        // https://www.codewithmukesh.com/blog/api-versioning-in-aspnet-core/

        builder.Services
            .AddCors(options => options.AddPolicy("CorsPolicy",
                builder => builder
                    .AllowAnyMethod()
                    .AllowCredentials()
                    .SetIsOriginAllowed((host) => true)
                    .AllowAnyHeader()))
            .AddApiVersioning(options =>
            {
                // default is 1.0 but it is clearer to specify
                options.DefaultApiVersion = new ApiVersion(1, 0);
                options.ReportApiVersions = true;
                options.ApiVersionReader = new UrlSegmentApiVersionReader();

            })
            .AddApiExplorer(options =>
            {
                options.GroupNameFormat = "'v'VVV";
                options.SubstituteApiVersionInUrl = true;
            })
            .AddOpenApi();

        // bit annoying that the builder type changes on what you are doing...
        // register for DI
        builder.Services
            .AddHttpLogging()
            .AddTransient<IBookRepository, InMemoryBookRepository>()
            .AddTransient<IBookService, BookService>();

        var app = builder.Build();

        // you should also think about Cors
        app.UseCors("CorsPolicy");

        // you should also think about authentication

        // think about telemetry - Appinsights etc
        // i'd think about structured logging like serilog
        // I also like policy based using something like DynamicProxy
        // this is configured in appsettings.Development.json
        app.UseHttpLogging();

        var apiVersions = app.NewApiVersionSet()
            .HasApiVersion(new ApiVersion(1))
            .Build();

        if (app.Environment.IsDevelopment())
        {
            // default is to /openapi/v1.json
            app.MapOpenApi().WithDocumentPerVersion();
            // the nice UI - view it at /scalar
            // omg and it has AI baked in by the look of it
            app.MapScalarApiReference();
        }

        app
            // You should have this on, generate a self signed cert etc
            // .UseHttpsRedirection();
            .MapControllers()
            .WithApiVersionSet(apiVersions);
        // you should also think about Cors
        

        app.Run();
    }
}

