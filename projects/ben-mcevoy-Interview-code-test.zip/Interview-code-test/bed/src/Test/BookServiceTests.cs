﻿using Api.Services.Books;
using Moq;

namespace Test;

public class BookServiceTests
{
    [Fact]
    public void BookService_get_books_by_owner()
    {
        // arrange
        var repository = MockBookRepo([new BookOwner("test", 55, [new Book("Book1", BookType.Ebook)])]);
        var sut = new BookService(repository);

        // act
        var actual = sut.GetBookOwners();

        // assert
        Assert.Equal(55, actual[0].Age);
    }

    [Fact]
    public void BookService_get_books_by_owner_over_18_is_adult()
    {
        // arrange
        var repository = MockBookRepo([
            new BookOwner("john", 55, [
                new Book("Aardvarks", BookType.Ebook),
                new Book("Antelopes", BookType.Ebook),
                ]),
            new BookOwner("bob", 12, [
                new Book("Aardvarks", BookType.Ebook),
                new Book("Zebras", BookType.Ebook),
                new Book("Antelopes", BookType.Ebook),
                ])                ,
            new BookOwner("Mary", 43, [
                new Book("Aardvarks", BookType.Ebook),
                new Book("Zebras", BookType.Ebook),
                new Book("Antelopes", BookType.Ebook),
                ])

        ]);
        var sut = new BookService(repository);

        // act
        var actual = sut.GetBookOwners().Where(x=>!x.IsAdult).ToList();

        // assert
        Assert.Equal("bob", actual[0].Name);
        Assert.Equal(12, actual[0].Age);
    }

    private static IBookRepository MockBookRepo(BookOwner[] bookOwners)
    {
        var mockRepo = new Mock<IBookRepository>();

        mockRepo.Setup(m => m.GetBookOwners())
            .Returns(() => bookOwners);

        return mockRepo.Object;
    }
}
