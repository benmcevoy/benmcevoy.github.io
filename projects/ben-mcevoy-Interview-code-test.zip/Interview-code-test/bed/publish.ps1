$configuration = "Release"
$project = "./src/Api/Api.csproj"
$outputFolder = "./deploy/Api"

if(Test-Path -path $outputFolder ) {
    Remove-Item -Path $outputFolder -Recurse -Force 
}

dotnet clean $project -c $configuration 
dotnet publish $project -c $configuration -o $outputFolder 
