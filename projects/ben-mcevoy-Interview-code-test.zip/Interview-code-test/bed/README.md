# OpenAPI service for books

Mimics the https://digitalcodingtest.bupa.com.au/swagger/index.html

It took about two hours to build this, without AI, and the first hour was spent understanding the new OpenAPI library.

This was useful - https://www.codewithmukesh.com/blog/api-versioning-in-aspnet-core/

This API is not strictly necessary, but was a worthwhile exercise.

The service is kept separate from the controller.  This allows easier refactoring to e.g. Azure Function, and avoids "fat controller".

## The Endpoints

Controller at: `/api/v1/bookowwers`

OpenAPI defintion: `/openapi/v1.json`

Scalar UI: `/scalar`

## CORS

Is not enabled on this endpoint.  Which is handy, as `https://digitalcodingtest.bupa.com.au/api/v1/bookowners` is missing allow-origin.

