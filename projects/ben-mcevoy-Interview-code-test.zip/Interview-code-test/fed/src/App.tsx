import './App.css'
import { GetBooks } from "./api/service"
import { Books as bookList } from "./components";

function App() {

  // well, it's the simple approach
  const queryParams = new URLSearchParams(window.location.search);
  const bookType = queryParams.get("bookType");
  const data = GetBooks(bookType ?? undefined);

  return (
    <>
      <section className="main">
        <h3 className="component-title">Owners and Books</h3>
        <div className="two-column">
          {data.map((books, index) => bookList(books, index))}
        </div>
        <hr />
        <section className="navigation">
          <a href="?bookType=Hardcover" >Hardcover only</a>
          <a href="/" className="button" >
            Get Books
          </a>
        </section>
      </section>
      <section className="spacer" />
    </>
  )
}

export default App