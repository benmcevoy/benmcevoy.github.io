import { assert, test, vi } from "vitest"
import { GetBooks as sut } from "./service.ts"
import type { BookOwner } from "./api.ts";

// data copied from https://digitalcodingtest.bupa.com.au/api/v1/bookowners
const mockJson =
    "[{\"name\":\"Jane\",\"age\":23,\"books\":[{\"name\":\"Hamlet\",\"type\":\"Hardcover\"},{\"name\":\"Wuthering Heights\",\"type\":\"Paperback\"}]},{\"name\":\"Charlotte\",\"age\":14,\"books\":[{\"name\":\"Hamlet\",\"type\":\"Paperback\"}]},{\"name\":\"Max\",\"age\":25,\"books\":[{\"name\":\"React: The Ultimate Guide\",\"type\":\"Hardcover\"},{\"name\":\"Gulliver's Travels\",\"type\":\"Hardcover\"},{\"name\":\"Jane Eyre\",\"type\":\"Paperback\"},{\"name\":\"Great Expectations\",\"type\":\"Hardcover\"}]},{\"name\":\"William\",\"age\":15,\"books\":[{\"name\":\"Great Expectations\",\"type\":\"Hardcover\"}]},{\"name\":\"Charles\",\"age\":17,\"books\":[{\"name\":\"Little Red Riding Hood\",\"type\":\"Hardcover\"},{\"name\":\"The Hobbit\",\"type\":\"Ebook\"}]}]";

const mockObject: BookOwner[] = JSON.parse(mockJson);

vi.mock(import('./api.ts'), () => ({ GetBooks: vi.fn() }))

import { GetBooks } from "./api.ts"

test('service can return booklist', () => {
    // arrange
    const mockApi = vi.mocked(GetBooks);
    mockApi.mockReturnValue({ data: mockObject } as any);

    // act
    let actual = sut();

    // assert
    assert.lengthOf(actual, 2)
    assert.lengthOf(actual[0]!.books, 6)
})

test('service can filter booklist by book type', () => {
    // arrange
    const mockApi = vi.mocked(GetBooks);
    mockApi.mockReturnValue({ data: mockObject } as any);

    // act
    let actual = sut("Hardcover");
    let adults = actual[0]!;

    assert.lengthOf(actual, 2)
    assert.equal(adults.title, "Books owned by Adults")
    assert.lengthOf(adults.books, 4)
})


test('service can filter booklist by book type', () => {
    // arrange
    const mockApi = vi.mocked(GetBooks);
    mockApi.mockReturnValue({ data: mockObject } as any);

    // act
    let actual = sut("Ebook");
    let allTheEBooks = actual[0]!.books.concat(actual[1]!.books);

    assert.lengthOf(allTheEBooks, 1)
})