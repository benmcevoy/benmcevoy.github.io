import { GetBooks as ApiGetBooks } from "../api/api"
import type { BookOwner } from "./api"

export interface BookList {
    title: string,
    books: string[]
}

const ToBookList = (bookOwners: BookOwner[], bookType?: string): BookList[] => {

    const adults = bookOwners.filter(x => x.age >= 18);
    const children = bookOwners.filter(x => x.age < 18);

    return [{
        title: "Books owned by Adults",
        books: adults
            .flatMap(x => x.books)
            .filter(x => x.type == (bookType ?? x.type))
            .map(x=>x.name)
            .sort()
    },
    {
        title: "Books owned by Children",
        books: children
            .flatMap(x => x.books)
            .filter(x => x.type == (bookType ?? x.type))
            .map(x=>x.name)
            .sort()
    }]
}

export const GetBooks = (bookType?: string): BookList[] => {
    const { data } = ApiGetBooks();

    if (data === undefined) return [{ title: "No books found", books: [] }];

    return ToBookList(data, bookType);
}
