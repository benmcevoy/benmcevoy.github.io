import createFetchClient from "openapi-fetch";
import createClient from "openapi-react-query";
import type { paths, components } from "@schema";

const fetchClient = createFetchClient<paths>({
    baseUrl: import.meta.env.VITE_API_BASE_URL
});

const $api = createClient(fetchClient);

export const GetBooks = () => $api.useQuery("get", "/api/v1/BookOwners");
export type BookOwner = components["schemas"]["BookOwner"]