import type { BookList } from "../api/service";

export const Books = (bookList: BookList, key: number) => {
    if(bookList.books.length === 0) return <></>

    return (
        <div key={key}>
            <h3 className="component-title"> {bookList.title} </h3>
            {bookList.books.map((book) => (<div>{book} </div>))}
        </div>
    );
}