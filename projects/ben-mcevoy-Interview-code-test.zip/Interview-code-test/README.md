## Background

 - ~~develop on windows vm~~ ubuntu 24
 - vs code only
 - powershell(pwsh) build scripts
 - .net 10.0.112
 - code must be of production quality - you get what you get in the time I have. 
 - node v24

## Qualities

- Functional
- Configurable
- Maintainable
- Testable
- Secure
- Deployable


## Boundaries

fed
bed - api
bed - core/db

## Stack

### FED

- React 
- generate the client - openapi-ts
- api endpoint - https://digitalcodingtest.bupa.com.au/swagger/index.html
- cors should be used
- ssl should be used, but probably skip it

The BUPA endpoint seems not to be configured for CORS.  

I'll copy the data out as a mock when testing.

**Components**

- Branding - The blue colour used throughout the app is #0079c8
- Layout/page container, with breakpoint at 600px
- "List"
  - list of books, with a header
- Nav container
  - has a hr at the top
    - link
    - button
    - these are both GET so should be links because standards

### BED
    
- openapi 
- thin controllers
- keep the "business" service seperate
- xunit test on core service only

## AI

I had to ask claude how to get the vitest mock to work. My Bad.

## Conclusions

I've written this all on Ubuntu with vscode. I don't run windows at home :)  I've not been able to test on windows, but should be fine.

I am not a fantastic front end dev, it's not often I write React.  I've used the template Vite gave me.

I do occassionally though, you can see https://github.com/benmcevoy/umbraco-headless-reference/ for an example.  I wrote that not too long after working on BUPA's Content-as-a-service platform.

I used a number of libraries I've never used before.  The openapi-ts stuff.  The C# OpenApi stuff.  Vite. Probably not a great idea as this all took way too long.  I'm not convinced I'm using the openapi-ts stuff correctly, I get types, which is good, but I find things like `components["schemas"]["BookOwner"]` rather smelly.

I initially was going to use the hey-api library, as I had used it before.  But it came up with a load of severe security issues, so yeah. Nah.

I "cheated" by making the links in the react app just be links. Crazy no?  The react way is useEffect/state and avoid page loads and so on.  

I've not documented this too much.  I'm a fan of markdown and keeping the docs with the code.

I kept everything client side.  React server components are a thing.