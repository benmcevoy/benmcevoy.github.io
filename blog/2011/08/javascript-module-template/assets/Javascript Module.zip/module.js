﻿var $fileinputname$ = (function() {

	"use strict";

	$(function() {
		init();
	});

	function init(options) {

	}

	return {
		init: init
	};

}());